When contributing to this repository, please first discuss the change you wish to make via the GitHub issue with the
owners of this repository before making a change. Unsolicited pull requests may be rejected without consideration. By
submitting a pull request into this repository, the contributor accepts the terms of the LICENSE agreement(s) and
acknowledges that the proposed change is legally compatible with the repository in every possible way and does not
impose any additional constraints on the repository after inclusion. In case the submitted change contains portions of
another open-source project, the pull request description must contain references to the original source code, and a
proper acknowledgement must be added to the README file.
