:orphan:

sngan_cifar10.py
================

.. literalinclude:: ../../../examples/sngan_cifar10.py