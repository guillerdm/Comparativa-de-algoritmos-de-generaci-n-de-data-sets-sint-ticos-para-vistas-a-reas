import os
import numpy as np
pip install gs
import gs

# Directorios de las carpetas de imágenes generadas y reales
folder_generated = "C:/Users/guill/OneDrive/Escritorio/imagenes_256"
folder_real = "C:/Users/guill/OneDrive/Escritorio/entrenamiento_prueba/progan2/Imagenes_progan1"

# Leer las imágenes generadas y reales
def load_images_from_folder(folder):
    images = []
    for filename in os.listdir(folder):
        img = plt.imread(os.path.join(folder, filename))
        if img is not None:
            images.append(img)
    return np.array(images)

# Cargar las imágenes generadas y reales
images_generated = load_images_from_folder(folder_generated)
images_real = load_images_from_folder(folder_real)

# Calcular los Relative Living Times (RLT)
rlt_generated = gs.rlts(images_generated, L_0=32, gamma=1.0/8, i_max=100, n=100)
rlt_real = gs.rlts(images_real, L_0=32, gamma=1.0/8, i_max=100, n=100)

# Calcular los Mean Relative Living Times (MRLT)
mrlt_generated = np.mean(rlt_generated, axis=0)
mrlt_real = np.mean(rlt_real, axis=0)

# Calcular la distancia L2 entre las distribuciones MRLT
distance = np.linalg.norm(mrlt_generated - mrlt_real)
print(f'Distancia L2 entre los MRLT: {distance}')